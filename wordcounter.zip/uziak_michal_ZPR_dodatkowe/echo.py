from pyamf import AMF3
from pyamf.remoting.client import RemotingService

gateway = 'http://127.0.0.1:8000/app/amf/call/amfrpc3'
client = RemotingService(gateway, amf_version = AMF3)
service = client.getService('srv.echo')

print service(' hello')
