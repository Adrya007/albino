import gluon.tools

mycalc = local_import('calc')

import logging

service = gluon.tools.Service(globals())

def call():
    session.forget()
    return service()

@service.amfrpc3("srv")
def echo(s):
    return mycalc.getWords(str(s))
