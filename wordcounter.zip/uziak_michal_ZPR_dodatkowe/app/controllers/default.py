## html controler for default html client
def index():
    return dict()
