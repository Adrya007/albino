#include <boost/python/module.hpp>
#include <boost/python/def.hpp>
#include <iostream>
#include <map>
#include <string>
#include <boost/algorithm/string/classification.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string.hpp>
#include<boost/tokenizer.hpp>

std::string getWords(std::string input){
  
  std::map<std::string, int> words;
  std::string wynikString;
  std::ostringstream oss;

   boost::algorithm::to_lower(input);
  
   boost::tokenizer<> tok(input);
   for(boost::tokenizer<>::iterator beg=tok.begin(); beg!=tok.end();++beg){
       	words[*beg]++;
   }

    for (std::map<std::string, int>::iterator it = words.begin(); it != words.end(); ++it)
      {
	oss<<it->first<<" "<<it->second<<"\n";
      }

   wynikString.append(oss.str());
    
   return wynikString;

 }

BOOST_PYTHON_MODULE(calc){

  boost::python::def("getWords",getWords);

}
