#include "backend.hpp"

Deck::Deck() {
    generateDeck();
    // Inicjalizacja generatora liczb pseudolosowych
    srand ( static_cast<unsigned int>(time(NULL)) );
    shuffleCards();
    cards_left=DECK_SIZE;
}

void Deck::generateDeck() {
    cards_.clear();
    for (int color = 0; color < 4; ++color) {
        for (int figure = 0; figure < 13; ++figure) {
            this->cards_.push_back(
                Card_ptr(new Card(color, figure)));
        }
    }
}

void Deck::shuffleCards() {
    random_shuffle(cards_.begin(), cards_.end());
}

Card_ptr Deck::getCard() {
    assert(cards_left > 0);
    Card_ptr card = *cards_.rbegin();
    cards_.pop_back();
    cards_left--;
    return card;
}

int Deck::getCardsLeft()
{
    return cards_left;
}
