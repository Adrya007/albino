#include "backend.hpp"

Player::Player(const string& name)
{
    name_ = name;
    type = -1;
}

void Player::setName(string name)
{
    name_ = name;
}

const string& Player::getName()
{
    return name_;
}

void Player::setCards(const Deck_ptr& deck)
{
      hand_cards.clear();
      hand_cards.push_back(deck->getCard());
      hand_cards.push_back(deck->getCard());
}

const vector<Card_ptr>& Player::getHandCards()
{
    return hand_cards;
}

const vector<Card_ptr>& Player::getBestCards()
{
    return best_cards;
}

bool Player::sortCards (const Card_ptr card1, const Card_ptr card2)
{
	return card1->getFigure() > card2->getFigure();
}

void Player::calculateHand(vector<Card_ptr>& tableCards)
{
	vector<Card_ptr> cards, cards_all;
	best_cards.clear();
	type=-1;
	cards_all.insert(cards_all.end(), hand_cards.begin(), hand_cards.end());			//dodanie kart gracza
	cards_all.insert(cards_all.end(), tableCards.begin(), tableCards.end());	//dodanie kart sto�u
	sort(cards_all.begin(),cards_all.end(),sortCards);

	for(int i = FULL_HAND_SIZE - 1; i >= 1; --i)
	{
		for(int j = FULL_HAND_SIZE - 2; j >= 0; --j)
		{
			if(i == j) continue;
			cards.clear();
			for(int k = 0; cards.size() < 5; ++k) {
				if(k != i && k != j) {
					cards.push_back(cards_all[k]);
				}
			}
			// tu zaczyna sie faktyczne liczenie pieciokartowej reki
			checkHand(cards);
		}
	}
}

void Player::checkHand(vector<Card_ptr>& cards)
{
	if ( hasRoyalFlush(cards) )
	{
		type = RoyalFlush;
		best_cards=cards;
	}
	else if (StraightFlush > type && hasStraightFlush(cards))
	{
		type = StraightFlush;
		best_cards=cards;
	}
	else if (FourOfAKind > type && hasFourOfAKind(cards))
	{
		type = FourOfAKind;
		best_cards=cards;
	}
	else if (FullHouse > type && hasFullHouse(cards))
	{
		type = FullHouse;
		best_cards=cards;
	}
	else if (Flush > type && hasFlush(cards))
	{
		type = Flush;
		best_cards=cards;
	}
	else if (Straight > type && hasStraight(cards))
	{
		type = Straight;
		best_cards=cards;
	}
	else if (ThreeOfAKind > type && hasThreeOfAKind(cards))
	{
		type = ThreeOfAKind;
		best_cards=cards;
	}
	else if (TwoPairs > type && hasTwoPairs(cards))
	{
		type = TwoPairs;
		best_cards=cards;
	}
	else if (OnePair > type && hasOnePair(cards))
	{
		type = OnePair;
		best_cards=cards;
	}
	else if (type == -1)
	{
		type = HighCard;
		best_cards=cards;
	}
}

bool Player::hasOnePair(vector<Card_ptr>& cards)
{
	if ( cards[0]->getFigure() == cards[1]->getFigure() )
	{
		return true;
	}
	else if ( cards[1]->getFigure() == cards[2]->getFigure() )
	{
		vector<Card_ptr> cards_tmp;
		cards_tmp.push_back( cards[1] );
		cards_tmp.push_back( cards[2] );
		cards_tmp.push_back( cards[0] );
		cards_tmp.push_back( cards[3] );
		cards_tmp.push_back( cards[4] );

		cards = cards_tmp;
		return true;
	}
	else if ( cards[2]->getFigure() == cards[3]->getFigure() )
	{
		vector<Card_ptr> cards_tmp;
		cards_tmp.push_back( cards[2] );
		cards_tmp.push_back( cards[3] );
		cards_tmp.push_back( cards[0] );
		cards_tmp.push_back( cards[1] );
		cards_tmp.push_back( cards[4] );

		cards = cards_tmp;
		return true;
	}
	else if ( cards[3]->getFigure() == cards[4]->getFigure() )
	{
		vector<Card_ptr> cards_tmp;
		cards_tmp.push_back( cards[3] );
		cards_tmp.push_back( cards[4] );
		cards_tmp.push_back( cards[0] );
		cards_tmp.push_back( cards[1] );
		cards_tmp.push_back( cards[2] );

		cards = cards_tmp;
		return true;
	}
	
	return false;
}


bool Player::hasTwoPairs(vector<Card_ptr>& cards)
{
	if ( (cards[0]->getFigure() == cards[1]->getFigure() &&
		cards[2]->getFigure() == cards[3]->getFigure() ) )
	{
		return true;
	}
	else if (cards[1]->getFigure() == cards[2]->getFigure() &&
		cards[3]->getFigure() == cards[4]->getFigure() ) 
	{
		vector<Card_ptr> cards_tmp;
		cards_tmp.push_back( cards[1] );
		cards_tmp.push_back( cards[2] );
		cards_tmp.push_back( cards[3] );
		cards_tmp.push_back( cards[4] );
		cards_tmp.push_back( cards[0] );

		cards = cards_tmp;
		return true;
	}
	else if (cards[0]->getFigure() == cards[1]->getFigure() &&
		cards[3]->getFigure() == cards[4]->getFigure() ) 
	{
		vector<Card_ptr> cards_tmp;
		cards_tmp.push_back( cards[0] );
		cards_tmp.push_back( cards[1] );
		cards_tmp.push_back( cards[3] );
		cards_tmp.push_back( cards[4] );
		cards_tmp.push_back( cards[2] );

		cards = cards_tmp;
		return true;
	}
	
	return false;
}


bool Player::hasThreeOfAKind(vector<Card_ptr>& cards)
{
	if (cards[0]->getFigure() == cards[1]->getFigure() &&
		cards[1]->getFigure() == cards[2]->getFigure() )
	{
		return true;
	}
	else if	(cards[1]->getFigure() == cards[2]->getFigure() &&
		cards[2]->getFigure() == cards[3]->getFigure() )
	{
		vector<Card_ptr> cards_tmp;
		cards_tmp.push_back( cards[1] );
		cards_tmp.push_back( cards[2] );
		cards_tmp.push_back( cards[3] );
		cards_tmp.push_back( cards[0] );
		cards_tmp.push_back( cards[4] );

		cards = cards_tmp;
	}
	else if ( (cards[2]->getFigure() == cards[3]->getFigure() &&
		cards[3]->getFigure() == cards[4]->getFigure() ) )
	{
		vector<Card_ptr> cards_tmp;
		cards_tmp.push_back( cards[2] );
		cards_tmp.push_back( cards[3] );
		cards_tmp.push_back( cards[4] );
		cards_tmp.push_back( cards[0] );
		cards_tmp.push_back( cards[1] );

		cards = cards_tmp;
		return true;
	}
	
	return false;
}


bool Player::hasStraight(vector<Card_ptr>& cards)
{
	if (cards[1]->getFigure() - 1 == cards[2]->getFigure() &&
		cards[2]->getFigure() - 1 == cards[3]->getFigure() &&
		cards[3]->getFigure() - 1 == cards[4]->getFigure() &&
		cards[0]->getFigure() - 1 == cards[1]->getFigure() )
	{
		return true;
	}
	else if (cards[1]->getFigure() - 1 == cards[2]->getFigure() &&
		cards[2]->getFigure() - 1 == cards[3]->getFigure() &&
		cards[3]->getFigure() - 1 == cards[4]->getFigure() &&
		cards[0]->getFigure() == CARD_A && cards[4]->getFigure() == CARD_2)
	{
		vector<Card_ptr> cards_tmp;
		cards_tmp.push_back( cards[1] );
		cards_tmp.push_back( cards[2] );
		cards_tmp.push_back( cards[3] );
		cards_tmp.push_back( cards[4] );
		cards_tmp.push_back( cards[0] );

		cards = cards_tmp;
		return true;
	}
	
	return false;
}



bool Player::hasFlush(vector<Card_ptr>& cards)
{
	if (cards[0]->getColor() == cards[1]->getColor() && cards[1]->getColor() == cards[2]->getColor() &&
		cards[2]->getColor() == cards[3]->getColor() && cards[3]->getColor() == cards[4]->getColor() )
		return true;
	
	return false;
}


bool Player::hasFullHouse(vector<Card_ptr>& cards)
{
	if ( cards[0]->getFigure() == cards[1]->getFigure() && cards[3]->getFigure() == cards[4]->getFigure() &&
		 cards[1]->getFigure() == cards[2]->getFigure() )
	{
		return true;
	}
	else if ( cards[0]->getFigure() == cards[1]->getFigure() && cards[3]->getFigure() == cards[4]->getFigure() &&
		cards[2]->getFigure() == cards[3]->getFigure() )
	{
		vector<Card_ptr> cards_tmp;
		cards_tmp.push_back( cards[2] );
		cards_tmp.push_back( cards[3] );
		cards_tmp.push_back( cards[4] );
		cards_tmp.push_back( cards[0] );
		cards_tmp.push_back( cards[1] );

		cards = cards_tmp;
		return true;
	}
	
	return false;
}


bool Player::hasFourOfAKind(vector<Card_ptr>& cards)
{
	if (cards[0]->getFigure() == cards[1]->getFigure() &&
		cards[1]->getFigure() == cards[2]->getFigure() &&
		cards[2]->getFigure() == cards[3]->getFigure() )
	{
		return true;
	}
	else if (cards[1]->getFigure() == cards[2]->getFigure() &&
		cards[2]->getFigure() == cards[3]->getFigure() &&
		cards[3]->getFigure() == cards[4]->getFigure() )
	{
		vector<Card_ptr> cards_tmp;
		cards_tmp.push_back( cards[1] );
		cards_tmp.push_back( cards[2] );
		cards_tmp.push_back( cards[3] );
		cards_tmp.push_back( cards[4] );
		cards_tmp.push_back( cards[0] );

		cards = cards_tmp;
		return true;
	}
	
	return false;
}


bool Player::hasStraightFlush(vector<Card_ptr>& cards) 
{
	if (cards[0]->getColor() == cards[1]->getColor() && cards[1]->getColor() == cards[2]->getColor() &&
		cards[2]->getColor() == cards[3]->getColor() && cards[3]->getColor() == cards[4]->getColor() &&
		cards[0]->getFigure() - 1 == cards[1]->getFigure() &&
		cards[1]->getFigure() - 1 == cards[2]->getFigure() &&
		cards[2]->getFigure() - 1 == cards[3]->getFigure() &&
		cards[3]->getFigure() - 1 == cards[4]->getFigure() )
	{
		return true;
	}
	else if (cards[0]->getColor() == cards[1]->getColor() && cards[1]->getColor() == cards[2]->getColor() &&
		cards[2]->getColor() == cards[3]->getColor() && cards[3]->getColor() == cards[4]->getColor() &&
		cards[1]->getFigure() - 1 == cards[2]->getFigure() &&
		cards[2]->getFigure() - 1 == cards[3]->getFigure() &&
		cards[3]->getFigure() - 1 == cards[4]->getFigure() &&
		cards[0]->getFigure() == CARD_A && cards[4]->getFigure() == CARD_2 )
	{
		vector<Card_ptr> cards_tmp;
		cards_tmp.push_back( cards[1] );
		cards_tmp.push_back( cards[2] );
		cards_tmp.push_back( cards[3] );
		cards_tmp.push_back( cards[4] );
		cards_tmp.push_back( cards[0] );

		cards = cards_tmp;
		return true;
	}
	
	return false;
}


bool Player::hasRoyalFlush(vector<Card_ptr>& cards) 
{
	if (cards[0]->getColor() == cards[1]->getColor() && cards[1]->getColor() == cards[2]->getColor() &&
		cards[2]->getColor() == cards[3]->getColor() && cards[3]->getColor() == cards[4]->getColor() &&
		cards[0]->getFigure() == CARD_A && cards[1]->getFigure() == CARD_K &&
		cards[2]->getFigure() == CARD_Q && cards[3]->getFigure() == CARD_J &&
		cards[4]->getFigure() == CARD_10)
		return true;
	
	return false;
}

const int Player::getType()
{
	return type;
}