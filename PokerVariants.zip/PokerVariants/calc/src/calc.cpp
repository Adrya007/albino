#include <boost/python.hpp>
#include <string>
#include "backend.hpp"

using namespace boost::python;

Deck_ptr deck = Deck_ptr(new Deck);
Player_ptr player(new Player("plr1"));
vector<Card_ptr> tableCards;
	    
void generateDeck()
{
    deck = Deck_ptr(new Deck);
}

string setPlayerCards()
{
    vector<Card_ptr> cards;
    player->setCards(deck);
    stringstream result;
    
    cards = player.get()->getHandCards();
    for(vector<Card_ptr>::iterator it = cards.begin(); it != cards.end(); ++it) {
        result << *(*it).get() << " ";
    }
    return result.str();
}

string setTableCards()
{
    tableCards.clear();
    for (int i = TABLE_SIZE; i; --i)
	tableCards.push_back(deck->getCard());
    
    stringstream result;
    for(vector<Card_ptr>::iterator it = tableCards.begin(); it != tableCards.end(); ++it) {
        result << *(*it).get() << " ";
    }
    return result.str();
}
    
string calculateHand()
{
    assert (player.get()->getHandCards().size() == 2 );
    
    assert (tableCards.size() == static_cast<unsigned int>(TABLE_SIZE) );
	
    player->calculateHand(tableCards);
    
    stringstream result;
    vector<Card_ptr> playerCards = player->getBestCards();
    result<<"Your best variant:"<<endl;
    for(vector<Card_ptr>::iterator it = playerCards.begin(); it != playerCards.end(); ++it) {
        result << *(*it).get() << " ";
    }
    result <<endl<<endl;
    
    int type = player->getType();
    
    if (type == RoyalFlush)
      result << "You have royal flush!";
    else if (type == StraightFlush)
      result << "You have straight flush!";
    else if (type == FourOfAKind)
      result << "You have four of a kind!";
    else if (type == FullHouse)
      result << "You have full house!";
    else if (type == Flush)
      result << "You have flush!";
    else if (type == Straight)
      result << "You have straight.";
    else if (type == ThreeOfAKind)
      result << "You have three of a kind.";
    else if (type == TwoPairs)
      result << "You have two pairs.";
    else if (type == OnePair)
      result << "You have one pair.";
    else
      result << "You have only high card.";
	
    return result.str();
}

BOOST_PYTHON_MODULE(calc)
{
    boost::python::def("generateDeck", generateDeck);
    boost::python::def("setPlayerCards", setPlayerCards);
    boost::python::def("setTableCards", setTableCards);
    boost::python::def("calculateHand", calculateHand);   
}