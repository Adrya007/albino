#include "backend.hpp"

Card::Card(const int& color, const int& figure) {
    color_ = color;
    figure_ = figure;
}

int Card::getColor() const
{
    return color_;
}

int Card::getFigure() const
{
    return figure_;
}

ostream& operator<< (ostream& oStream, const Card& card) {
    const string color_str[] = {
        "C", "D", "H", "S"
    };
    const string figure_str [] = {
        "2", "3", "4", "5", "6",
        "7", "8", "9", "10",
        "J", "Q", "K", "A"
    };
    return oStream << figure_str[card.figure_] << color_str[card.color_];
}
