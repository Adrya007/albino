#pragma once

// STL includes
#include <algorithm>
#include <vector>

// Boost includes
#include <boost/random.hpp>
#include <boost/shared_ptr.hpp>

// C++ includes
#include <iostream>

//Project includes
#include "Card.hpp"
#include "Deck.hpp"
#include "Player.hpp"

using namespace std;

const int DECK_SIZE = 52;
const int CARDS_IN_COLOR = 13;

const int TABLE_SIZE = 5;
const int HAND_SIZE = 5;
const int FULL_HAND_SIZE = 7;

const int COLOR_CLUBS = 0;
const int COLOR_DIAMONDS = 1;
const int COLOR_HEARTS = 2;
const int COLOR_SPADES = 3;

const int CARD_2 = 0;
const int CARD_3 = 1;
const int CARD_4 = 2;
const int CARD_5 = 3;
const int CARD_6 = 4;
const int CARD_7 = 5;
const int CARD_8 = 6;
const int CARD_9 = 7;
const int CARD_10 = 8;
const int CARD_J = 9;
const int CARD_Q = 10;
const int CARD_K = 11;
const int CARD_A = 12;

enum {HighCard, OnePair, TwoPairs, ThreeOfAKind, Straight, Flush,
      FullHouse, FourOfAKind, StraightFlush, RoyalFlush};