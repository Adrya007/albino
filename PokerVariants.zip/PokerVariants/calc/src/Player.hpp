#pragma once
#include "backend.hpp"

using namespace std;

class Player
{
    private:
	// Przechowuje nick gracza i wektor jego aktualnych kart
        string name_;
        vector<Card_ptr> hand_cards;
        vector<Card_ptr> best_cards;
	int type;		//uklad na rece
    public:
        Player();
        Player(const string& name);

        const vector<Card_ptr>& getHandCards();
        const vector<Card_ptr>& getBestCards();
        void setCards(const Deck_ptr& deck);

        void setName(string name);
        const string& getName();

	const int getType();
		
	static bool sortCards (const Card_ptr card1, const Card_ptr card2);
	void calculateHand(vector<Card_ptr>&);		// obliczenie najsilniejszego zestawu 5 z 7 kart
	void checkHand(vector<Card_ptr>& cards);
		
	int checkHighCard(vector<Card_ptr>& cards);
	bool hasRoyalFlush(vector<Card_ptr>& cards);
	bool hasStraightFlush(vector<Card_ptr>& cards);
	bool hasFourOfAKind(vector<Card_ptr>& cards);
	bool hasFullHouse(vector<Card_ptr>& cards);
	bool hasFlush(vector<Card_ptr>& cards);
	bool hasStraight(vector<Card_ptr>& cards);
	bool hasThreeOfAKind(vector<Card_ptr>& cards);
	bool hasTwoPairs(vector<Card_ptr>& cards);
	bool hasOnePair(vector<Card_ptr>& cards);
	bool hasHighCard(vector<Card_ptr>& cards);
};

typedef boost::shared_ptr<Player> Player_ptr;