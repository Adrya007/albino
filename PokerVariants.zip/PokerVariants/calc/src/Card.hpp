#pragma once
#include "backend.hpp"

using namespace std;

class Card {
    public:
        Card(const int& color, const int& figure);

        int getColor() const;
        int getFigure() const;

        friend ostream& operator<<(ostream& oStream, const Card& card);

    private:
        int color_, figure_;
};

typedef boost::shared_ptr<Card> Card_ptr;