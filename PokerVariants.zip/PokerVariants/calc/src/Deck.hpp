#pragma once
#include "backend.hpp"

using namespace std;

class Deck {
    // Symuluje tali� kart
    public:
        Deck();

        void shuffleCards();
        void generateDeck();

        Card_ptr getCard();
	int getCardsLeft();

    private:
        vector<Card_ptr> cards_;
	int cards_left;
};

typedef boost::shared_ptr<Deck> Deck_ptr;