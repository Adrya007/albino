import gluon.tools

mycalc = local_import('calc')

import logging

service = gluon.tools.Service(globals())

def call():
    session.forget()
    return service()
    
@service.amfrpc3("srv")
def generateDeck():
    return str(mycalc.generateDeck())
    
@service.amfrpc3("srv")
def setPlayerCards():
    return str(mycalc.setPlayerCards())
    
@service.amfrpc3("srv")
def setTableCards():
    return str(mycalc.setTableCards())
    
@service.amfrpc3("srv")
def calculateHand():
    return str(mycalc.calculateHand())