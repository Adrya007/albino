import cStringIO, urllib, Image, gluon.tools

mycalc = local_import('calc')
service = gluon.tools.Service(globals())

def call():
    session.forget()
    return service()

@service.amfrpc3("srv")
def echo(url):
    try:
        im = Image.open(cStringIO.StringIO(urllib.urlopen(url).read())).convert("L") # Wczytaj obrazek o podanym URL i przekonwertuj go do skali szarości
    except IOError:
        return "Given URL does not point to an image." 
    return mycalc.getAscii(list(im.getdata()), im.size[0]) # Pierwszy arg. to lista wartości jasności kolejnych pikseli, drugi to szerokość obrazka
