#include <boost/python.hpp>
#include <string>

using namespace boost::python;
using namespace std;

typedef unsigned char byte;

const int MAX_BYTES = 10 * 1024 * 1024; // 10 MB
const int SYMBOLS_SIZE = 16;
const int QUANT = 256 / SYMBOLS_SIZE;
const char symbols[SYMBOLS_SIZE] =
{ '#', '$', '@', 'X', 'O', 'x', '=', '+', '/', ';', ':', '~', '-', ',', '.', ' ' };

string getAscii(const list& img, const int width)
{
	const int SIZE = len(img);
	if (SIZE > MAX_BYTES)
	{
		return "Too big image.";
	}
	const int HEIGHT = SIZE / width;
	string ascii;
	ascii.resize(SIZE + HEIGHT);
	for (int y = 0; y < HEIGHT; ++y)
	{
		for (int x = 0; x < width; ++x)
		{
			byte px = extract<byte>(img[y * width + x]);
			ascii[y * (width + 1) + x] = symbols[px / QUANT];
		}
		ascii[y * (width + 1) + width] = '\n';
	}
	return ascii;
}

BOOST_PYTHON_MODULE(calc)
{
    def("getAscii", getAscii);
}
